package conditions;

import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter your age please...");
        double age=scanner.nextInt();
        System.out.println("Your age is : " + age);

    }
}
