package conditions;

public class Ex2 {
    public static void main(String[] args) {
        int num=31;
        if (num%2==0){
            System.out.println("The num is zugi number");
        }else {
            System.out.println("The num is not zugi number");
        }
    }
}
