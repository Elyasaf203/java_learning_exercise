package conditions;

public class Ex3 {
    public static void main(String[] args) {
        int a=1,b=1;
        if (a>b){
            System.out.println("The a is bigger");
        }else if(b>a){
            System.out.println("The b is bigger");
        }else {
            System.out.println("The two numbers is the same");
        }
    }
}
