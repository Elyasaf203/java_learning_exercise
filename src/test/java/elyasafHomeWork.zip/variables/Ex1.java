package variables;

public class Ex1 {
    public static void main(String[] args) {
        int myAge=28;
        long mySalary=15000;
        String myAddress="Migdal Haemek";
        String myName="Elyasaf Ohayon";
        double myHeight=1.70;
        System.out.println("My age is: "+myAge + "\n" + "My address is: " + myAddress +"\n" +"End my name is: " +myName + " My height is: " +myHeight + " My salary is: " +mySalary + "שח ");

        //After change;
        System.out.println();
        myAge=30;
        mySalary=17000;
        myAddress="Tel-aviv";
        myName="ely";
        myHeight=1.80;

        System.out.println("My age is: "+myAge + "\n" + "My address is: " + myAddress +"\n" +"End my name is: " +myName + " My height is: " +myHeight + " My salary is: " +mySalary + "שח ");

    }
}
