package variables;

public class Ex7 {
    public static void main(String[] args) {
        int radios=10;
        double pi=3.14159265;
        int rectangeleHeight=10;
        double rectangeleWidth=5.15;
        double resultsCircle=(pi*radios)*radios;
        double resultsRectangle=rectangeleHeight*rectangeleWidth;
        System.out.println("The area for the circle is: " +resultsCircle);
        System.out.println("The area for rectangle is: " +resultsRectangle);
        System.out.println("The area for the circle is: " +resultsCircle + " The area for rectangle is: " +resultsRectangle);
    }
}
