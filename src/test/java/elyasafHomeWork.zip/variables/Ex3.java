package variables;

public class Ex3 {
    public static void main(String[] args) {
        int myAge = 28;
        double employeeSalary = 17000;
        boolean whetherSomebodyHesDogOrNot =true;
        String firstName ="Elyasaf";
    }
}
