package variables;

public class Ex2 {
    public static void main(String[] args) {
        int myAge=23;
        System.out.println("My age +5 is: "+ (myAge+5));
        System.out.println("My age *3 is: "+ myAge*3);
    }
}
