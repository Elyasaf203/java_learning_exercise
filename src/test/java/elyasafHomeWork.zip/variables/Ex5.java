package variables;

public class Ex5 {
    public static void main(String[] args) {
        int a=18,b=42;
        int first=(a+b)*3;
        int second=a+b*2;
        System.out.println("The first v");
        System.out.println("first number is: "+first);
        System.out.println("second number is: "+second);
    }
}
