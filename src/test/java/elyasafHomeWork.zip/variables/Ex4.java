package variables;

public class Ex4 {
    public static void main(String[] args) {
        System.out.println("The first line print math action end second line print String");
        System.out.println(3+4+5);
        System.out.println("3+4+5");

    }
}
