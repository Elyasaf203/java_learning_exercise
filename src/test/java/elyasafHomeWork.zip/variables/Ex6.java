package variables;

public class Ex6 {
    public static void main(String[] args) {
        long number=10;
        System.out.println(number+20);
        System.out.println(number/2);
        System.out.println(number*4);
    }
}
